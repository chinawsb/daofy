"""
版本信息

版权所有 (C) 吉林省左右软件开发有限公司
Copyright (C) Equilibrium Software Development Co., Ltd, Jilin
Update & Mod By Crystalxp (黑夜杀手 QQ:281309196)

版本号: 2026.04.29
发布日期: 2026-04-29
"""

__version__ = "2026.04.29"
__release_date__ = "2026-04-29"
__author__ = "吉林省左右软件开发有限公司"
__copyright__ = "Copyright (C) 2026 吉林省左右软件开发有限公司 / Equilibrium Software Development Co., Ltd, Jilin"
__license__ = "MIT"
